#include<time.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

void input_info();
void regi_new();
void donate_blood();
void print_donate();
void sortbybirth(DONATE donate_info[]);
void sortbyday();
void print_stuff();
void input_stuff();
void input_blood();
void print_blood();
void supervise_stuff();
void add_amount();
void add_stuff();
void rewrite_info();
void rewrite_blood();
void rewrite_stuff();
void choose_stuff();
int check_possible(int);
int resultbydonate(int);
