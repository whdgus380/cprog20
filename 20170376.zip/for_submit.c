#include "main.h"
#define SIZE 200
#define ZERO 0



typedef struct _donate{
		char name[10];
		char blood_type[10];
		char phone[25];
		char birth[10];
		int regi_year;
		int regi_mon;
		int regi_day;
		int last_year;
		int last_mon;
		int last_day;
		int donate_cnt;
}DONATE;

typedef struct node{
	int idx;
	int birth;
	struct node * next;
}node_t;

typedef struct _stuff{
	char name[20];
	int cnt;
}STUFF;

typedef struct _blood{
	char type[10];
	int amount;
}BLOOD;

STUFF stuff_info[10];
DONATE donate_info[SIZE];
BLOOD blood_info[10];

int d_idx = 0;
int s_idx = 0;
int b_idx = 0;



int main()
{
	int sel = 1;
	void (*pf)(void);


	input_info();
	input_stuff();
	input_blood();
		
	while(sel!=0)
	{
		printf("\n\n\n\n-------------------------------\n");
		printf("<헌혈관리 프로그램>\n");
		printf("-------------------------------\n");
		printf("1.신규헌혈자 등록\n");
		printf("2.헌혈\n");
		printf("3.전체헌혈자 정보조회\n");
		printf("4.헌혈사은품 조회\n");
		printf("5.헌혈사은품 관리\n");
		printf("6.혈액형별 헌혈 현황조회\n");
		printf("0.종료(반드시 0을눌러 종료해주세요)\n");
		printf("-------------------------------\n");
		printf("항목을 선택하세요:\n");
		scanf("%d",&sel);

		switch(sel)
		{
			case 1:
				regi_new();
				break;
			case 2:
				donate_blood();
				break;
			case 3:
				print_donate();
				break;
			case 4:
				print_stuff();
				break;
			case 5:
				supervise_stuff();
				break;
			case 6:
				print_blood();
				break;

			case 0:
				printf("\n종료되었습니다\n");
				break;

			default:
				printf("\n잘못입력했습니다\n");
				break;
						
		}		
	
	}

	rewrite_stuff();
	rewrite_blood();
	rewrite_info();
}


