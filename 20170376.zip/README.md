fun.c 와 main.h 와 for_submit.c 를 가지고 gcc 컴파일을 해보려 했으나 되지 않았습니다. 메이크 파일도 아직 만들지 못했습니다..

그래서 소스전체인 submit.c 파일과 텍스트파일3개(blood_info.txt,donate_info.txt, stuff_info) 를 같이 올립니다. 죄송합니다..
