
#include<time.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define SIZE 200
#define ZERO 0
typedef struct _donate{
		char name[10];
		char blood_type[10];
		char phone[25];
		char birth[10];
		int regi_year;
		int regi_mon;
		int regi_day;
		int last_year;
		int last_mon;
		int last_day;
		int donate_cnt;
}DONATE;

typedef struct node{
	int idx;
	int birth;
	struct node * next;
}node_t;

typedef struct _stuff{
	char name[20];
	int cnt;
}STUFF;

typedef struct _blood{
	char type[10];
	int amount;
}BLOOD;

STUFF stuff_info[10];
DONATE donate_info[SIZE];
BLOOD blood_info[10];

int d_idx = 0;
int s_idx = 0;
int b_idx = 0;

void input_info();
void regi_new();
void donate_blood();
void print_donate();
void sortbybirth(DONATE donate_info[]);
void sortbyday();
void print_stuff();
void input_stuff();
void input_blood();
void print_blood();
void supervise_stuff();
void add_amount();
void add_stuff();
void rewrite_info();
void rewrite_blood();
void rewrite_stuff();
void choose_stuff();
int check_possible(int);
int resultbydonate(int);


int main()
{
	int sel = 1;
	void (*pf)(void);


	input_info();
	input_stuff();
	input_blood();
		
	while(sel!=0)
	{
		printf("\n\n\n\n-------------------------------\n");
		printf("<헌혈관리 프로그램>\n");
		printf("-------------------------------\n");
		printf("1.신규헌혈자 등록\n");
		printf("2.헌혈\n");
		printf("3.전체헌혈자 정보조회\n");
		printf("4.헌혈사은품 조회\n");
		printf("5.헌혈사은품 관리\n");
		printf("6.혈액형별 헌혈 현황조회\n");
		printf("0.종료(반드시 0을눌러 종료해주세요)\n");
		printf("-------------------------------\n");
		printf("항목을 선택하세요:\n");
		scanf("%d",&sel);

		switch(sel)
		{
			case 1:
				regi_new();
				break;
			case 2:
				donate_blood();
				break;
			case 3:
				print_donate();
				break;
			case 4:
				print_stuff();
				break;
			case 5:
				supervise_stuff();
				break;
			case 6:
				print_blood();
				break;

			case 0:
				printf("\n종료되었습니다\n");
				break;

			default:
				printf("\n잘못입력했습니다\n");
				break;
						
		}		
	
	}

	rewrite_stuff();
	rewrite_blood();
	rewrite_info();
}



void input_info(void)
{
	FILE *d_fp = NULL;
    d_fp = fopen("donate_info.txt", "r");

	if(d_fp == NULL){
		printf("Failed to open file %s\n","donate_info.txt");
	}

    char line[200];
    char *buffer;
    int word_cnt;
 
    while (fscanf(d_fp, "%s", line) > 0)
    {
        word_cnt = 0;
        buffer = strtok(line, " ,");
        while (buffer != NULL)
        {
            word_cnt++;
            switch (word_cnt)
            {
            case 1:  
                strcpy(donate_info[d_idx].name, buffer);
                break;
            case 2: 
                strcpy(donate_info[d_idx].blood_type, buffer);
                break;
            case 3:  
                strcpy(donate_info[d_idx].phone, buffer);
                break;
            case 4:
				strcpy(donate_info[d_idx].birth, buffer);
                break;
            case 5:
				donate_info[d_idx].regi_year = atoi(buffer);
                break;
            case 6:
				donate_info[d_idx].regi_mon = atoi(buffer);
                break;
            case 7:  
				donate_info[d_idx].regi_day = atoi(buffer);
                break;
            case 8:  
				donate_info[d_idx].last_year = atoi(buffer);
				break;
            case 9:  
				donate_info[d_idx].last_mon = atoi(buffer);
				break;
            case 10:  
				donate_info[d_idx].last_day = atoi(buffer);
				break;
            case 11:  
				donate_info[d_idx].donate_cnt = atoi(buffer);
				break;
            }
            buffer = strtok(NULL, " ,");
        }
        d_idx++;
    }

    fclose(d_fp);
}


void regi_new()
{
	time_t timer;
	struct tm *t;
	int time_now = timer = time(NULL);
	int check = 0;
	t = localtime(&timer);
    FILE* d_fp = fopen("donate_info.txt", "a");
 
  	printf("이름 : ");
    scanf("%s", donate_info[d_idx].name);
	printf("혈액형 : ");
    scanf("%s", donate_info[d_idx].blood_type);
	printf("핸드폰 : ");
    scanf("%s", donate_info[d_idx].phone);
	printf("생년월일(6자리): ");
    scanf("%s", donate_info[d_idx].birth);
	donate_info[d_idx].regi_year = t->tm_year-100;
	donate_info[d_idx].regi_mon = t->tm_mon +1;
	donate_info[d_idx].regi_day = t->tm_mday;
	
	for(int i=0;i<d_idx;i++)	
		if(strcmp(donate_info[i].name,donate_info[d_idx].name)==0 || strcmp(donate_info[i].phone,donate_info[d_idx].phone) ==0)
			check = 1;

	
	if(check==1){
		printf("\n이미 등록된 정보입니다. 관리자에게 문의하세요\n");
		return;
	}

    fprintf(d_fp, "\n%s,%s,%s,%s,%d,%d,%d,%d,%d,%d,%d"
        , donate_info[d_idx].name
        , donate_info[d_idx].blood_type
        , donate_info[d_idx].phone
		, donate_info[d_idx].birth
		, donate_info[d_idx].regi_year
		, donate_info[d_idx].regi_mon
		, donate_info[d_idx].regi_day
        , ZERO, ZERO, ZERO,ZERO);
 
    d_idx++;
    fclose(d_fp);
}


void donate_blood()
{
	char name[10] = "";
	char *p = name;
	char phone[20] = "";
	int choice;
	int check1 = 0;
	int check2 = 0;
	int idx = 0;
	int (*pf)(int);
	
	pf = check_possible;

	printf("정보를 조회할 방법을 입력하시오. 1.이름,2.연락처\n");
	scanf("%d",&choice);

	switch(choice)
	{
		case 1:
			printf("이름 입력\n");
			scanf("%s",name);
			printf("-------------------------------\n");
			break;
		case 2:
			printf("연락처 입력\n");
			printf("-------------------------------\n");
			scanf("%s",phone);
			break;
		default:
			printf("일치하는 이름이나 연락처가 없습니다\n");
			break;
	}
	
		for(int m=0;m<d_idx;m++){
			if(strcmp(name,donate_info[m].name) ==0 || strcmp(phone,donate_info[m].phone) ==0){
				idx = m;
				check1 =1;
				break;
			}

		}

	check2 = pf(idx);


	if(check1 == 0){
		printf("정보가 없어 헌혈이 불가합니다. 먼저 등록해주세요\n");
		return;
	}
	else if(check2 == 0){
		printf("조건을 만족하지 못해 헌혈이 불가합니다\n");
		printf("지난 헌혈일로부터 8주가 지났나요?\n");
		printf("연 5회 이하로 하였나요?\n");
		return;
	}
	else if (check1 == 1 || check2 == 1){
		printf("\n헌혈이 가능합니다. 사은품을 선택해주세요\n");
		printf("-------------------------------\n");
		choose_stuff();
		pf = resultbydonate;
		pf(idx);
		
	
	}

}

void sortbybirth(DONATE donate_info[])
{
	int tmp_birth = 0;
	int tmp_idx;
	int idx;
	node_t* new_node;
	node_t* list_head = NULL;
	node_t* next_p;
	node_t* prev_p;

	for(int cnt = 0;cnt<d_idx;cnt++){
		tmp_birth = atoi(donate_info[cnt].birth);
		tmp_idx = cnt;

		new_node = (node_t*) malloc (sizeof(node_t));
		new_node -> birth = tmp_birth;
		new_node -> idx = tmp_idx;
		next_p = list_head;
		prev_p = NULL;

		while(next_p){
			if(next_p -> birth > new_node->birth)
				break;
			prev_p = next_p;
			next_p = next_p ->next;
		}

		new_node->next = next_p;

		if(prev_p){
			prev_p ->next = new_node;
		}
		else{
			list_head = new_node;
		}


		
	}


	while(list_head !=NULL)
	{
		idx =list_head ->idx;
		printf("%3s %s %s %s 등록:%2d%02d%02d 마지막헌혈:%2d%02d%02d 헌혈횟수:%2d\n",
			donate_info[idx].name,
			donate_info[idx].blood_type,
			donate_info[idx].phone,
			donate_info[idx].birth,
			donate_info[idx].regi_year,
			donate_info[idx].regi_mon,
			donate_info[idx].regi_day,
			donate_info[idx].last_year,
			donate_info[idx].last_mon,
			donate_info[idx].last_day,
			donate_info[idx].donate_cnt);

		list_head = list_head ->next;
		printf("\n");
	}

}


	
void sortbyday()
{
	for(int i=0;i<d_idx;i++){
		printf("%3s %s %s %s 등록:%2d%02d%02d 마지막헌혈:%2d%02d%02d 헌혈횟수:%2d\n",
			donate_info[i].name,
			donate_info[i].blood_type,
			donate_info[i].phone,
			donate_info[i].birth,
			donate_info[i].regi_year,
			donate_info[i].regi_mon,
			donate_info[i].regi_day,
			donate_info[i].last_year,
			donate_info[i].last_mon,
			donate_info[i].last_day,
			donate_info[i].donate_cnt);
			
		printf("\n");
	}


}

void print_donate()
{
	int choice;
	printf("-------------------------------\n");
	printf("1.등록날짜별 정렬, 2.생년월일별 정렬\n");
	printf("-------------------------------\n");
	scanf("%d",&choice);

	switch(choice){
		case 1:
			sortbyday();
			break;
		case 2:
			sortbybirth(donate_info);
			break;
		default:
			printf("1과2 이외의 값을 입력했습니다\n");
			return ;
				
	}

}

void input_stuff()
{
	FILE *s_fp = NULL;
	char line[100];
	char *buffer;
	int word_cnt;

	s_fp = fopen("stuff_info.txt","r");

	if(s_fp ==NULL)
	{
		printf("파일을 열수없습니다\n");
	}


	while(fscanf(s_fp, "%s", line)>0)
	{
		word_cnt = 0;
		buffer = strtok(line," ,");
		while(buffer !=NULL)
		{
			word_cnt ++;
			switch(word_cnt)
			{
				case 1:
					strcpy(stuff_info[s_idx].name,buffer);
					break;
				case 2:
					stuff_info[s_idx].cnt = atoi(buffer);
					break;
				default:
					printf("잘못입력");
					break;
			}
			buffer = strtok(NULL, " ,");
		}
		s_idx ++;

	}

	fclose(s_fp);

}
void print_stuff()
{

	for(int i=0;i<s_idx;i++){
		
		printf("%s %d개",stuff_info[i].name,stuff_info[i].cnt);
			if(stuff_info[i].cnt <= 30)
				printf("\t구매필요");
	
	printf("\n");
	}
}


void input_blood()
{
	FILE *b_fp = NULL;
	char line[100];
	char *buffer;
	int word_cnt;

	b_fp = fopen("blood_info.txt","r");

	if(b_fp ==NULL)
	{
		printf("파일을열수없습니다\n");
	}

	while(fscanf(b_fp, "%s", line)>0)
	{
		word_cnt = 0;
		buffer = strtok(line," ,");
		while(buffer !=NULL)
		{
			word_cnt ++;
			switch(word_cnt)
			{
				case 1:
					strcpy(blood_info[b_idx].type,buffer);
					break;
				case 2:
					blood_info[b_idx].amount = atoi(buffer);
					break;
				default:
					printf("잘못입력");
					break;
			}
			buffer = strtok(NULL, " ,");
		}
		b_idx ++;

	}

	fclose(b_fp);

}
void print_blood()
{

	for(int i=0;i<b_idx;i++){
		printf("%2s %5d",blood_info[i].type,blood_info[i].amount);
		if(blood_info[i].amount >= 10000)
			printf("  양호");
		else if(blood_info[i].amount <10000 || blood_info[i].amount >=3000)
			printf("  부족");
		else
			printf("  위험");
	
	printf("\n");
	}
}


void supervise_stuff()
{
	FILE* s_fp = fopen("stuff_info.txt","a");
	int check = 0;
	printf("1. 품목 추가, 2.재고 추가");
	scanf("%d",&check);

	switch(check){
		case 1:
			add_stuff();
			break;
		case 2:
			add_amount();
			break;
		default:
			printf("1이나2 이외의 값을 입력했습니다");
			return;
	}
}



void add_stuff()
{
	char name[20];
	int amount;

	printf("어떤 새로운  품목을 추가하시겠습니까?");
	scanf("%s",name);
	printf("수량은 몇개입니까?");
	scanf("%d",&amount);

	strcpy(stuff_info[s_idx].name,name);
	stuff_info[s_idx].cnt = amount;
	
	s_idx ++;
}

void add_amount()
{
	char name[20];
	int target_idx;
	int howmany;
	int check =0;
	for(int i=0;i<s_idx;i++)
		printf("%s %d \n",stuff_info[i].name, stuff_info[i].cnt);

	printf("어떤 품목의 재고를 추가합니까?");
	scanf("%s",name);
	printf("몇개를 추가합니까?");
	scanf("%d",&howmany);

	for(int i=0;i<s_idx;i++){
		if(strcmp(name,stuff_info[i].name) == 0){
			target_idx = i;
			check=1;
	
		}
	}
	if(check ==0){
		printf("잘못 입력하셨습니다\n");
			return;
	}
			
	stuff_info[target_idx].cnt += howmany;
	printf("등록되었습니다\n");

}

void rewrite_stuff()
{
	FILE* rs_fp = fopen("stuff_info.txt","w");

	for(int i=0;i<s_idx;i++){
		fprintf(rs_fp,"%s,%d\n"
				, stuff_info[i].name
				, stuff_info[i].cnt);
	}

	fclose(rs_fp);
}

void rewrite_blood()
{
	FILE* rb_fp = fopen("blood_info.txt","w");

	for(int i=0;i<b_idx;i++){
		fprintf(rb_fp,"%s,%d\n"
				, blood_info[i].type
				, blood_info[i].amount);
	}

	fclose(rb_fp);
}

void rewrite_info()
{
	FILE* rd_fp = fopen("donate_info.txt","w");

	for(int i=0; i<d_idx;i++){

	fprintf(rd_fp, "%s,%s,%s,%s,%d,%d,%d,%d,%d,%d,%d\n"
        , donate_info[i].name
        , donate_info[i].blood_type
        , donate_info[i].phone
		, donate_info[i].birth 
		, donate_info[i].regi_year
		, donate_info[i].regi_mon
		, donate_info[i].regi_day
		, donate_info[i].last_year
		, donate_info[i].last_mon
		, donate_info[i].last_day
		, donate_info[i].donate_cnt);
	}
	
	fclose(rd_fp);
}

int check_possible(int idx)
{
	time_t timer;
	struct tm *t;
	int time_now =  timer = time(NULL);
	int diff_year,diff_mon,diff_day,diff_date;
	t = localtime(&timer);
	
	diff_year = (t-> tm_year -100) - donate_info[idx].last_year;
	diff_mon = (t-> tm_mon +1) - donate_info[idx].last_mon;
	diff_day = (t->tm_mday) - donate_info[idx].last_day;
	diff_date = diff_year * 365 + diff_mon*30 + diff_day;

	if(donate_info[idx].donate_cnt > 5 || diff_date <= 7*8)
		return 0;
	else
		return 1;
}

void choose_stuff()
{
	char name[20];
	int target_idx;
	int check =0;
	for(int i=0;i<s_idx;i++)
		printf("%s\n",stuff_info[i].name);

	printf("-------------------------------\n");
	printf("어떤 사은품을 원하십니까? 이름을 정확히 입력하시오\n\n");
	scanf("%s",name);

	for(int i=0;i<=s_idx;i++){
		if(strcmp(name,stuff_info[i].name) == 0){
			target_idx = i;
			check=1;
	
		}
	}
	if(check ==0){
		printf("잘못 입력하셨습니다choose_stuff");
			return;
	}
			
	stuff_info[target_idx].cnt -= 1;
	printf("-------------------------------\n");
	printf("사은품과 헌혈정보가 모두 기입됐습니다.\n");

}

int resultbydonate(int idx)
{
	time_t timer;
	struct tm *t;
	int time_now = timer = time(NULL);
	t = localtime(&timer);

	int blood_idx=30;

	for(int i=0;i<b_idx;i++)
		if(strcmp(donate_info[idx].blood_type, blood_info[i].type) ==0)
			blood_idx = i;
	

	blood_info[blood_idx].amount += 300;
	donate_info[idx].donate_cnt +=1;
	donate_info[idx].last_year = t->tm_year - 100;
	donate_info[idx].last_mon = t->tm_mon +1;
	donate_info[idx].last_day = t->tm_mday;


}
